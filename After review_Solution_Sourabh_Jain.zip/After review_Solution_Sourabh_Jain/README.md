# Image Classification [Dog Breed] using AWS SageMaker

Use AWS Sagemaker to train a pretrained model that can perform image classification by using the Sagemaker profiling, debugger, hyperparameter tuning and other good ML engineering practices. This can be done on either the provided dog breed classication data set or one of your choice.

## Intro

- Used sagemaker to use a pretrained model to identify dog breeds by providing image of the dog to the endpoint.

## Project Set Up and Installation
Enter AWS through the gateway in the course and open SageMaker Studio. 
Download the starter files.
Download/Make the dataset available. 

## Files used in the project

- **hpo.py** contains code that will help in hyperparameter tuning so that we can find the best hyperparameters based on the loss function.
- **train_model.py** contains code to train the model using the selected hyper paramters that we got from hpo.py
- **inference2.py** having code that will help in getting and passing the info to and from endpoint and 

## Dataset
The provided dataset is the dogbreed classification dataset which can be found in the classroom.
The project is designed to be dataset independent so if there is a dataset that is more interesting or relevant to your work, you are welcome to use it to complete the project.

### Access
Upload the data to an S3 bucket through the AWS Gateway so that SageMaker has access to the data. 

- Uploaded the data to S3 bucket using python code that can be viewed in the jupyter file.



## Hyperparameter Tuning
What kind of model did you choose for this experiment and why? Give an overview of the types of parameters and their ranges used for the hyperparameter search

Remember that your README should:
- Include a screenshot of completed training jobs
- Logs metrics during the training process
- Tune at least two hyperparameters
- Retrieve the best best hyperparameters from all your training jobs

## Completed Training jobs

- Please find below screenshots of training jobs

### Hyperparameter Tuning Job

![plot](./Images/hyperparameter_tuning.png)

![plot](./Images/trainingjobs.png)

#

## Main training job

![plot](./Images/main_training1.png)

## Best Hyperparameters

![plot](./Images/main_training2.png)

## Debugging and Profiling
**TODO**: Give an overview of how you performed model debugging and profiling in Sagemaker

- First I set the debugging and profiling rules, and then set up the hooks for profiling and debugging and then did a trial run and then the results were generated.

### Results
**TODO**: What are the results/insights did you get by profiling/debugging your model?

- I got various insights from the profiling, like I could have selected GPU based instances which was required, but I completed using CPU based standard instance only (to save cost) and how increasing batch size would have helped. There are various recommendations that can be viewed in the profiling html file that is also in the zip file.

**TODO** Remember to provide the profiler html/pdf file in your submission.

-  Provided in zip file


## Model Deployment
**TODO**: Give an overview of the deployed model and instructions on how to query the endpoint with a sample input.

- You can query the endpoint with the instructions in the notebook at the end, mainly the endpoint needs data to be passed as image bytes as part of payload.

**TODO** Remember to provide a screenshot of the deployed active endpoint in Sagemaker.

![plot](./Images/endpoint.png)

## Standout Suggestions
**TODO (Optional):** This is where you can provide information about any standout suggestions that you have attempted.
